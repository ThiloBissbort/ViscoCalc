%This viscosity model is based on Hui & Zhang (2007)

function [result_Hui_Zhang_2007_viscosity,log10n_specT_Hui_Zhang_2007] = hui_zhang_2007_single(T_C,wt_norm_hz07)


%% ------------INPUT SECTION-----------------------------------------------

wt_SiO2 = wt_norm_hz07(1);
wt_TiO2 = wt_norm_hz07(2);
wt_Al2O3 = wt_norm_hz07(3);
wt_FeOt = wt_norm_hz07(4);
wt_MnO = wt_norm_hz07(5);
wt_MgO = wt_norm_hz07(6);
wt_CaO = wt_norm_hz07(7);
wt_Na2O = wt_norm_hz07(8);
wt_K2O = wt_norm_hz07(9);
wt_P2O5 = wt_norm_hz07(10);
wt_H2O = wt_norm_hz07(11);


%Give a specific temperature for which a viscosity is calculated

T_K = T_C +273;


%--------setting up temperature arrays-------------------------------------
T_C_array = zeros(1,1201);
T_C_array(1) = 300;

for i=2:1201
    T_C_array(i) = T_C_array(i-1)+1;
end

T_K_array = T_C_array + 273;

inv_T_K_array = 10000./T_K_array;


%-------Converting wt.% oxides to molar fraction X------------------------------------
% OK. all values were compared to excel sheet

[X_SiO2,X_TiO2,X_Al2O3,X_FeOt,X_MnO,X_MgO,X_CaO,X_Na2O,X_K2O,X_P2O5,X_H2O] = wt_to_X(wt_SiO2,wt_TiO2,wt_Al2O3,wt_FeOt,wt_MnO,wt_MgO,wt_CaO,wt_Na2O,wt_K2O,wt_P2O5,wt_H2O);

mole_frac_all = [X_SiO2,X_TiO2,X_Al2O3,X_FeOt,X_MnO,X_MgO,X_CaO,X_Na2O,X_K2O,X_P2O5,X_H2O];
total_mole_frac = sum(mole_frac_all);

X_NaKO05 = (X_Na2O+X_K2O)*2;
X_ALO15 = X_Al2O3*2;
if X_NaKO05 > X_ALO15
X_NaKAlO2 = X_ALO15;
elseif X_NaKO05 < X_ALO15
    X_NaKAlO2 = X_NaKO05;
elseif X_NaKO05 == X_ALO15
    X_NaKAlO2 = X_NaKO05;
end

X_Al2O3ex = (X_ALO15 - X_NaKAlO2)/2;
X_NaK2Oex = (X_NaKO05 - X_NaKAlO2)/2;
X_FeMnO = X_FeOt + X_MnO;




%% --------------------Calculation of parameters--------------------------
% Z is OK. 
% A is OK
% B is OK.
% C is OK.
% D is OK.
Z_array = zeros(1,1201);
A_computed_array = zeros(1,1201);
B_computed_array = zeros(1,1201);
C_computed_array = zeros(1,1201);
D_computed_array = zeros(1,1201);
log10_n_array = zeros(1,1201);

for i = 1:1201
Z_array(i) = X_H2O^(1/(1+(185.797/T_K_array(i)))); 
A_computed_array(i) = (-6.83*X_SiO2-170.79*X_TiO2-14.71*X_Al2O3ex-18.01*X_MgO-19.76*X_CaO+34.31*X_NaK2Oex-140.38*Z_array(i)+159.26*X_H2O-8.43*X_NaKAlO2);
B_computed_array(i) = (18.14*X_SiO2+248.93*X_TiO2+32.61*X_Al2O3ex+25.96*X_MgO+22.64*X_CaO-68.29*X_NaK2Oex+38.84*Z_array(i)-48.55*X_H2O+16.12*X_NaKAlO2)*1000;
C_computed_array(i) = (21.73*X_Al2O3ex-61.98*X_FeMnO-105.53*X_MgO-69.92*X_CaO-85.67*X_NaK2Oex+332.01*Z_array(i)-432.22*X_H2O-3.16*X_NaKAlO2);
D_computed_array(i) = (2.16*X_SiO2-143.05*X_TiO2-22.10*X_Al2O3ex+38.56*X_FeMnO+110.83*X_MgO+67.12*X_CaO+58.01*X_NaK2Oex+384.77*X_P2O5-404.97*Z_array(i)+513.75*X_H2O)*1000;
end

%% -----------------Calculate log10(n) and n over temperature--------------
%equation 4
for i = 1:1201
    log10_n_array(i) = A_computed_array(i)+(B_computed_array(i)/T_K_array(i))+exp(C_computed_array(i)+(D_computed_array(i)/T_K_array(i)));
end

%calculation of viscosity 
n_array = 10.^(log10_n_array);


%% ------------------Calculate log10(n) at specific temperature-----------

Z_specT = X_H2O^(1/(1+(185.797/T_K))); 
A_computed_specT = (-6.83*X_SiO2-170.79*X_TiO2-14.71*X_Al2O3ex-18.01*X_MgO-19.76*X_CaO+34.31*X_NaK2Oex-140.38*Z_specT+159.26*X_H2O-8.43*X_NaKAlO2);
B_computed_specT = (18.14*X_SiO2+248.93*X_TiO2+32.61*X_Al2O3ex+25.96*X_MgO+22.64*X_CaO-68.29*X_NaK2Oex+38.84*Z_specT-48.55*X_H2O+16.12*X_NaKAlO2)*1000;
C_computed_specT = (21.73*X_Al2O3ex-61.98*X_FeMnO-105.53*X_MgO-69.92*X_CaO-85.67*X_NaK2Oex+332.01*Z_specT-432.22*X_H2O-3.16*X_NaKAlO2);
D_computed_specT = (2.16*X_SiO2-143.05*X_TiO2-22.10*X_Al2O3ex+38.56*X_FeMnO+110.83*X_MgO+67.12*X_CaO+58.01*X_NaK2Oex+384.77*X_P2O5-404.97*Z_specT+513.75*X_H2O)*1000;

log10n_specT_Hui_Zhang_2007 = A_computed_specT+(B_computed_specT/T_K)+exp(C_computed_specT+(D_computed_specT/T_K));

%% ------------------Calculate Tg(�C) and fragility index m---------------

%Tg is derived by rearranging the VFT equation and using n = 10^12 Pas

%% -----------------Save results in matrix--------------------------------

result_Hui_Zhang_2007_viscosity = [T_C_array;log10_n_array]';

fclose('all');
