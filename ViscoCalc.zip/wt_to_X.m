% wt. % to mol wt %

function [X_SiO2,X_TiO2,X_Al2O3,X_FeOt,X_MnO,X_MgO,X_CaO,X_Na2O,X_K2O,X_P2O5,X_H2O] = wt_to_X(wt_SiO2,wt_TiO2,wt_Al2O3,wt_FeOt,wt_MnO,wt_MgO,wt_CaO,wt_Na2O,wt_K2O,wt_P2O5,wt_H2O);

M_SiO2 = 60.0848;
M_TiO2 = 79.87;
M_Al2O3 = 101.96128;
M_FeOt = 71.84;
M_MnO = 70.94;
M_MgO = 40.3044;
M_CaO = 56.0794;
M_Na2O = 61.98;
M_K2O = 94.2;
M_P2O5 = 141.94;
M_H2O = 18.02;

y_SiO2 = wt_SiO2/M_SiO2;
y_TiO2 = wt_TiO2/M_TiO2;
y_Al2O3 = wt_Al2O3/M_Al2O3;
y_FeOt = wt_FeOt/M_FeOt;
y_MnO = wt_MnO/M_MnO;
y_MgO = wt_MgO/M_MgO;
y_CaO = wt_CaO/M_CaO;
y_Na2O = wt_Na2O/M_Na2O;
y_K2O = wt_K2O/M_K2O;
y_P2O5 = wt_P2O5/M_P2O5;
y_H2O = wt_H2O/M_H2O;

x_sum = y_SiO2+y_TiO2+y_Al2O3+y_FeOt+y_MnO+y_MgO+y_CaO+y_Na2O+y_K2O+y_P2O5+y_H2O;

X_SiO2 = y_SiO2/x_sum;
X_TiO2 = y_TiO2/x_sum;
X_Al2O3 = y_Al2O3/x_sum;
X_FeOt = y_FeOt/x_sum;
X_MnO = y_MnO/x_sum;
X_MgO = y_MgO/x_sum;
X_CaO = y_CaO/x_sum;
X_Na2O = y_Na2O/x_sum;
X_K2O = y_K2O/x_sum;
X_P2O5 = y_P2O5/x_sum;
X_H2O = y_H2O/x_sum;
