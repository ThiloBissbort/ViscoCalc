% wt. % to mol wt %

function [mol_SiO2,mol_TiO2,mol_Al2O3,mol_FeOt,mol_MnO,mol_MgO,mol_CaO,mol_Na2O,mol_K2O,mol_P2O5,mol_H2O,mol_F2O] = wt_to_mol(wt_SiO2,wt_TiO2,wt_Al2O3,wt_FeOt,wt_MnO,wt_MgO,wt_CaO,wt_Na2O,wt_K2O,wt_P2O5,wt_H2O,wt_F2O);

M_SiO2 = 60.0848;
M_TiO2 = 79.87;
M_Al2O3 = 101.96128;
M_FeOt = 71.84;
M_MnO = 70.94;
M_MgO = 40.3044;
M_CaO = 56.0794;
M_Na2O = 61.98;
M_K2O = 94.2;
M_P2O5 = 141.94;
M_H2O = 18.02;
M_F2O = 54.00;

x_SiO2 = wt_SiO2/M_SiO2;
x_TiO2 = wt_TiO2/M_TiO2;
x_Al2O3 = wt_Al2O3/M_Al2O3;
x_FeOt = wt_FeOt/M_FeOt;
x_MnO = wt_MnO/M_MnO;
x_MgO = wt_MgO/M_MgO;
x_CaO = wt_CaO/M_CaO;
x_Na2O = wt_Na2O/M_Na2O;
x_K2O = wt_K2O/M_K2O;
x_P2O5 = wt_P2O5/M_P2O5;
x_H2O = wt_H2O/M_H2O;
x_F2O = wt_F2O/M_F2O;

x_sum = x_SiO2+x_TiO2+x_Al2O3+x_FeOt+x_MnO+x_MgO+x_CaO+x_Na2O+x_K2O+x_P2O5+x_H2O+x_F2O;

mol_SiO2 = x_SiO2/x_sum*100;
mol_TiO2 = x_TiO2/x_sum*100;
mol_Al2O3 = x_Al2O3/x_sum*100;
mol_FeOt = x_FeOt/x_sum*100;
mol_MnO = x_MnO/x_sum*100;
mol_MgO = x_MgO/x_sum*100;
mol_CaO = x_CaO/x_sum*100;
mol_Na2O = x_Na2O/x_sum*100;
mol_K2O = x_K2O/x_sum*100;
mol_P2O5 = x_P2O5/x_sum*100;
mol_H2O = x_H2O/x_sum*100;
mol_F2O = x_F2O/x_sum*100;
