function [wt_norm_g08,wt_norm_hz07] = norm_to_100wt(wt_SiO2,wt_TiO2,wt_Al2O3,wt_FeOt,wt_MnO,wt_MgO,wt_CaO,wt_Na2O,wt_K2O,wt_F2O,wt_P2O5,wt_H2O,dec_norm)
%normalize all oxides to 100 wt%
if dec_norm == 1
    %for giordano et al. 2008
    oxides_g08 = [wt_SiO2;wt_TiO2;wt_Al2O3;wt_FeOt;wt_MnO;wt_MgO;wt_CaO;wt_Na2O;wt_K2O;wt_F2O;wt_P2O5;wt_H2O];
    total_g08 = sum(oxides_g08);
    f_g08 = total_g08/100;
    wt_norm_g08 = oxides_g08./f_g08;
    
    %for hui and zhang 2007
    oxides_hz07 = [wt_SiO2;wt_TiO2;wt_Al2O3;wt_FeOt;wt_MnO;wt_MgO;wt_CaO;wt_Na2O;wt_K2O;wt_P2O5;wt_H2O];
    total_hz07 = sum(oxides_hz07);
    f_hz07 = total_hz07/100;
    wt_norm_hz07 = oxides_hz07./f_hz07;
    
elseif dec_norm == 0
    %for giordano et al. 2008
    anhydr_oxides_g08 = [wt_SiO2;wt_TiO2;wt_Al2O3;wt_FeOt;wt_MnO;wt_MgO;wt_CaO;wt_Na2O;wt_K2O;wt_F2O;wt_P2O5];
    anhydr_total_g08 = sum(anhydr_oxides_g08);
    f_g08 = anhydr_total_g08/(100-wt_H2O);
    wt_norm_g08 = anhydr_oxides_g08./f_g08;
    wt_norm_g08 = [wt_norm_g08;wt_H2O];
    
    %for hui and zhang 2007
    anhydr_oxides_hz07 = [wt_SiO2;wt_TiO2;wt_Al2O3;wt_FeOt;wt_MnO;wt_MgO;wt_CaO;wt_Na2O;wt_K2O;wt_P2O5];
    anhydr_total_hz07 = sum(anhydr_oxides_hz07);
    f_hz07 = anhydr_total_hz07/(100-wt_H2O);
    wt_norm_hz07 = anhydr_oxides_hz07./f_hz07;
    wt_norm_hz07 = [wt_norm_hz07;wt_H2O];
end
    
fclose('all');