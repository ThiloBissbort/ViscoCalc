%This viscosity model is based on Giordano et al. | Earth and
%Planetary Science Letters 271 (2008) 123-134

function [result_Giordano_etal_2008_viscosity,log10n_specT_Giordano_etal_2008,Tg_C_Giordano_etal_2008,m_Giordano_etal_2008] = Giordano_etal_2008_single(T_C,wt_norm_g08)

%% ------------INPUT SECTION-----------------------------------------------

wt_SiO2 = wt_norm_g08(1);
wt_TiO2 = wt_norm_g08(2);
wt_Al2O3 = wt_norm_g08(3);
wt_FeOt = wt_norm_g08(4);
wt_MnO = wt_norm_g08(5);
wt_MgO = wt_norm_g08(6);
wt_CaO = wt_norm_g08(7);
wt_Na2O = wt_norm_g08(8);
wt_K2O = wt_norm_g08(9);
wt_F2O = wt_norm_g08(10);
wt_P2O5 = wt_norm_g08(11);
wt_H2O = wt_norm_g08(12);


%Give a specific temperature for which a viscosity is calculated

T_K = T_C +273;

%--------setting up temperature arrays-------------------------------------
T_C_array = zeros(1,1201);
T_C_array(1) = 300;

for i=2:1201
    T_C_array(i) = T_C_array(i-1)+1;
end

T_K_array = T_C_array + 273;

inv_T_K_array = 10000./T_K_array;

%-------setting up the b- and c-values-------------------------------------

b1_value = 159.6;
b2_value = -173.3;
b3_value = 72.1;
b4_value = 75.7;
b5_value = -39;
b6_value = -84.1;
b7_value = 141.5;
b11_value = -2.43;
b12_value = -0.91;
b13_value = 17.6;

c1_value = 2.75;
c2_value = 15.7;
c3_value = 8.3;
c4_value = 10.2;
c5_value = -12.3;
c6_value = -99.5;
c11_value = 0.3;


%-------Converting wt.% oxides to mol %------------------------------------
[mol_SiO2,mol_TiO2,mol_Al2O3,mol_FeOt,mol_MnO,mol_MgO,mol_CaO,mol_Na2O,mol_K2O,mol_P2O5,mol_H2O,mol_F2O] = wt_to_mol(wt_SiO2,wt_TiO2,wt_Al2O3,wt_FeOt,wt_MnO,wt_MgO,wt_CaO,wt_Na2O,wt_K2O,wt_P2O5,wt_H2O,wt_F2O);

mol_V = mol_H2O+mol_F2O;
mol_TA = mol_TiO2+mol_Al2O3;
mol_FM = mol_FeOt+mol_MnO+mol_MgO;
mol_NK = mol_Na2O+mol_K2O;

%% --------------------Calculation of parameters--------------------------

b1_result = b1_value*(mol_SiO2+mol_TiO2); 
b2_result = b2_value*(mol_Al2O3); 
b3_result = b3_value*(mol_FeOt+mol_MnO+mol_P2O5); 
b4_result = b4_value*(mol_MgO);
b5_result = b5_value*(mol_CaO);
b6_result = b6_value*(mol_Na2O+mol_V);
b7_result = b7_value*(mol_V+log(1+mol_H2O));
b11_result = b11_value*((mol_SiO2+mol_TiO2)*mol_FM);
b12_result = b12_value*((mol_SiO2+mol_TA+mol_P2O5)*(mol_NK+mol_H2O));
b13_result = b13_value*(mol_Al2O3*mol_NK);

c1_result = c1_value*(mol_SiO2);
c2_result = c2_value*(mol_TA);
c3_result = c3_value*(mol_FM);
c4_result = c4_value*(mol_CaO);
c5_result = c5_value*(mol_NK);
c6_result = c6_value*(log(1+mol_V));
c11_result = c11_value*((mol_Al2O3+mol_FM+mol_CaO-mol_P2O5)*(mol_NK+mol_V));

A_constant = -4.55;
B_computed = b1_result+b2_result+b3_result+b4_result+b5_result+b6_result+b7_result+b11_result+b12_result+b13_result;
C_computed = c1_result+c2_result+c3_result+c4_result+c5_result+c6_result+c11_result;

%% -----------------Calculate log10(n) and n over temperature--------------
% eq. 1 of this paper

log10_n_array = zeros(1,1201);

%calculation of log10(viscosity) using the VFT equation
for i = 1:1201
    log10_n_array(i) = A_constant+(B_computed/(T_K_array(i)-C_computed));
end

%calculation of viscosity 
n_array = 10.^(log10_n_array);

%% ------------------Calculate log10(n) at specific temperature-----------

%calculation of log10(viscosity) at specific T
log10n_specT_Giordano_etal_2008 = A_constant+(B_computed/(T_K-C_computed));

%% ------------------Calculate Tg(�C) and fragility index m---------------

%Tg is derived by rearranging the VFT equation and using n = 10^12 Pas

Tg_K = B_computed/(log10(10^12)-A_constant)+C_computed;
Tg_C = Tg_K-273;
Tg_C_Giordano_etal_2008 = Tg_C;
m = B_computed/(Tg_K*(1-C_computed/Tg_K)^2);
m_Giordano_etal_2008 = m;

%% -----------------Save results in matrix--------------------------------

result_Giordano_etal_2008_viscosity = [T_C_array;log10_n_array]';

fclose('all');
